package com.jwind.cachedemo.mapper;

import com.jwind.cachedemo.bean.Teacher;
import org.apache.ibatis.annotations.Select;

/**
 * @author zhoujl
 * @date 2021/1/10
 */
public interface TeacherMapper {

    @Select("SELECT * FROM teacher where id = #{id}")
    public Teacher getid(String id);

}
