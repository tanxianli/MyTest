package com.jwind.cachedemo.conterllor;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhoujl
 * @date 2021/1/10
 */
@RestController
public class test {

    @RequestMapping("/tt")
    public String test(){

        return "ok";
    }

}


