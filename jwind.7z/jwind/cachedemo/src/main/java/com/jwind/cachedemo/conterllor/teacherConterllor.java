package com.jwind.cachedemo.conterllor;

import com.jwind.cachedemo.bean.Teacher;
import com.jwind.cachedemo.mapper.TeacherMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhoujl
 * @date 2021/1/10
 */
@RestController
@RequestMapping("/teacher")
public class teacherConterllor {

    @Autowired
    private TeacherMapper mapper;

    @RequestMapping(value={"/id/{id}"})
    @Cacheable(value = "cs",key = "#id")
    public Teacher getid(@PathVariable String id){
      return  mapper.getid(id);
    }

    @RequestMapping(value={"/delete/id/{id}"})
    @CacheEvict(value = "cs",key = "#id")
    public void delete(String id){
        System.out.println("执行");
    }


    @RequestMapping(value={"update"})
    @CachePut(value = "cs",key = "teacher.id")
    public Teacher update(Teacher teacher){
       // return  mapper.getid(id);
        return null;
    }
}
