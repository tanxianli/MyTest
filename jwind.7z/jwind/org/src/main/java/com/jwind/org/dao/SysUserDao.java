package com.jwind.org.dao;


import com.jwind.comp.dao.BasicBeanDao;
import com.jwind.org.bean.SysUnit;
import com.jwind.org.bean.SysUser;
import org.springframework.stereotype.Component;


@Component("orgSysUserDao")
public class SysUserDao extends BasicBeanDao<SysUser> {

    public SysUnit qid(String id) throws Exception {
        SysUnit unit = this.getBeanDaoHelper().queryById(SysUnit.class,id);
        return unit;
    }

    public SysUnit add(SysUnit unit) throws Exception {
        this.getBeanDaoHelper().saveInsert(SysUnit.class,unit,null);
        return unit;
    }

    public SysUnit upd(SysUnit unit) throws Exception {
        this.getBeanDaoHelper().saveUpdate(SysUnit.class,unit,null);
        return unit;
    }

    public int del(SysUnit unit) throws Exception {
        return  this.getBeanDaoHelper().saveDelete(SysUnit.class,unit,null);
    }

}
