package com.jwind.org.conterllor;

import com.jwind.org.bean.SysUnit;
import com.jwind.org.dao.SysUserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhoujl
 * @date 2021/1/13
 */
@RestController
@RequestMapping("/org")
public class test {

   @Autowired
   private SysUserDao dao;

   @RequestMapping(value = "/test",method = RequestMethod.GET)
   public SysUnit gett() throws Exception {
    return dao.qid("1");
   }

   @RequestMapping(value = "/add",method = RequestMethod.GET)
   public SysUnit gadd() throws Exception {
      SysUnit unit = new SysUnit();
      unit.setUnitName("ssss");
      unit.setUnitFullName("谭显立");
      return dao.add(unit);
   }

   @RequestMapping(value = "/upd",method = RequestMethod.GET)
   public SysUnit gadd(String name) throws Exception {
      SysUnit unit = dao.qid("1");
      unit.setUnitName(name);
      return dao.upd(unit);
   }

   @RequestMapping(value = "/del",method = RequestMethod.GET)
   public int del(String id) throws Exception {
      SysUnit unit = dao.qid(id);
      return dao.del(unit);
   }
}
