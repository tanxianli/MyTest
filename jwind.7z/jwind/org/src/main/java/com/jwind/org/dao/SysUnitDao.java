package com.jwind.org.dao;


import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.dao.BasicBeanDao;
import com.jwind.comp.user.User;
import com.jwind.org.bean.SysUnit;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component("orgSysUnitDao")
public class SysUnitDao extends BasicBeanDao<SysUnit> {


    @Override
    public void preInsert(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit保存前");
        super.preInsert(bean, map, user);
    }

    @Override
    public void afterInsert(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit保存后");
        super.afterInsert(bean, map, user);
    }

    @Override
    public void preUpdate(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit修改前");
        super.preUpdate(bean, map, user);
    }

    @Override
    public void afterUpdate(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit修改后");
        super.afterUpdate(bean, map, user);
    }

    @Override
    public void preDelete(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit删除前");
        super.preUpdate(bean, map, user);
    }

    @Override
    public void afterDelete(SysUnit bean, Map map, User user) {
        System.err.println("SysUnit删除后");
        super.afterUpdate(bean, map, user);
    }
}