package com.jwind.comp.util.aspose;

import com.alibaba.fastjson.JSONArray;
import com.aspose.words.*;
import com.aspose.words.net.System.Data.DataRow;
import com.aspose.words.net.System.Data.DataSet;
import com.aspose.words.net.System.Data.DataTable;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;


/**
 * @author zhoujl
 * @date 2020/11/19
 */
public class AsposeJavaW {

    private Document doc;

    private DocumentBuilder builder;

    /**
     * @param resousePath 资源模板所在地址
     */
    public AsposeJavaW(String resousePath) throws Exception {
        init(resousePath);
    }

    /**
     * 处理key - value 形式数据 (不支持换行)
     * @param map  eg:  map.put(""year","2020"),
     * 模板中用法:[#year]
     */
    public void savekeyValue(Map map) throws Exception {
        FindReplaceOptions options = new FindReplaceOptions();
        options.setDirection(FindReplaceDirection.BACKWARD);
        options.setReplacingCallback(new DomainReplaceHandler(map));
        doc.getRange().replace(Pattern.compile("\\[#(\\w+)\\]"), "", options);
        doc.updateFields();
    }

    /**
     * 处理替换形式数据 (支持换行) html导入
     * @param map  eg:  map.put(""cs","这是一条测试文本"),
     * 模板中用法:{{cs}}
     */
    public void replaceTxt(Map map,String type){
        Section mainsc = doc.getSections().get(0);
        ParagraphCollection pc = mainsc.getBody().getParagraphs();
        Set set = map.keySet();
        for (Paragraph p : pc.toArray()) {
            set.forEach(e->{
                if (p.getText().contains("{{"+e.toString()+"}}")) {
                    try {
                        builder.moveTo(p);
                    if("html".equals(type)){ //html
                        String html = WordTool.processImgUrl((String)map.get(e.toString()));
                        builder.insertHtml(html);
                    }else {  //文本
                        builder.write("\n");
                        builder.writeln((String) map.get(e.toString()));
                    }
                        p.remove();
                    }catch (Exception e1) {
                        e1.printStackTrace();
                    }
                }
            });
        }
    }

    /**
     * 处理Lsit形式数据 JSON.toJSONString(list)
     * @param map  eg:  map.put("csbeanList",JSON.toJSONString(list)),
     * 模板中用法:<<foreach [p in csbeanList]>> <<[p.对象属性]>> <</foreach>>
     */
    public void saveList(Map map) throws Exception {
        Set set = map.keySet();
        ReportingEngine engine = new ReportingEngine();
        DataSet ds = new DataSet();
        set.forEach(e->{
            DataTable dt = new DataTable(e.toString());
            JSONArray jsonArray = JSONArray.parseArray((String) map.get(e.toString()));
            int i = 0;
            for (Object obj: jsonArray) {
                DataRow row = dt.newRow();
                Map var1 = (Map)obj;
                Set var2 = var1.keySet();
                for(Object var2e:var2){
                    if(i==0) dt.getColumns().add(var2e.toString());
                    row.set(var2e.toString(),var1.get(var2e.toString()));
                }
                i++;
                dt.getRows().add(row);
            }
            ds.getTables().add(dt);
        });
        engine.buildReport(doc, ds, "ds");
    }


    public ByteArrayOutputStream colse() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        doc.save(bos, SaveFormat.DOCX);
        return bos;
    }

    public void init(String resousePath) throws Exception {
        InputStream is = this.getClass().getResourceAsStream(resousePath);
        if(is==null) throw new RuntimeException("找不到模板文件:"+resousePath);
        doc = new Document(is);
        builder = new DocumentBuilder(doc);
    }

    private class DomainReplaceHandler implements IReplacingCallback {
        private Map<String, String> data = null;
        public DomainReplaceHandler(Map<String, String> data) {
            this.data = data;
        }
        @Override
        public int replacing(ReplacingArgs arg) throws Exception {
            String key = arg.getMatch().group(1);
            String value = data.get(key);
            if (value == null) {
                value = "";
            }
            arg.setReplacement(value);
            return ReplaceAction.REPLACE;
        }
    }

}
