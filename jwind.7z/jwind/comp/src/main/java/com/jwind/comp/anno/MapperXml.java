package com.jwind.comp.anno;

import java.lang.annotation.*;


/**
 * namespace xml的namespace
 * defaultQuery 默认查询
 */
@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
public @interface MapperXml {

    String defaultQuery() default "queryList";

    String compId();

    String xmlFile();

}
