package com.jwind.comp.manger.bean;

import com.jwind.comp.manger.bean.Ids;
import com.jwind.comp.manger.bean.Result;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zhoujl
 * @date 2021/1/14
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(
        name = "resultMap"
)
public class ResultMap {

    @XmlAttribute(
            name = "id"
    )
    private String id;

    @XmlAttribute(
            name = "type"
    )
    private String type;


    private List<Result> result;

    @XmlElement(
            name = "id"
    )
    private List<Ids> idresult;

    public ResultMap() {
    }

    public List<Result> getResult() {
        if (this.result == null) {
            this.result = new ArrayList();
        }
        return this.result;
    }

    public List<Ids> getIds() {
        if (this.idresult == null) {
            this.idresult = new ArrayList();
        }
        return this.idresult;
    }
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


}
