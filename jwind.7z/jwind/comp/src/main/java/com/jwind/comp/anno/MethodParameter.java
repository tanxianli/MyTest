package com.jwind.comp.anno;

import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
public @interface MethodParameter {
    boolean common() default false;

    String tx() default "";

    String desc() default "";

    String detailDesc() default "";

    String[] exceptionDesc() default {};

    String httpMethod() default "*";

    boolean isWebApi() default true;

    int orderNum() default 100;

    String postName() default "";

    Class<?>[] postType() default {};

    String[] writeDataSource() default {};

    String methodUrl() default "/";

    String queryString() default "";

    String returnDesc() default "";

    Class<?>[] returnType() default {};

    String userParam() default "";
}