package com.jwind.comp.util.aspose;

import com.aspose.words.*;
import com.jwind.comp.util.AddressUtils;
import org.springframework.beans.factory.annotation.Value;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author zhoujl
 * @date 2020/11/25
 */
public class WordTool {

    @Value("${fileserver.url}")
    private static String url;


    /**
     * 将html中的相对路径替换为绝对路径，方便插入到word中
     * @param html
     * @return
     */
    public static String processImgUrl(String html, String fileurl) {
        try {
            if (html == null) return "";
            if (!fileurl.endsWith("/")) fileurl = fileurl.concat("/");
            return repairContent(html,fileurl);
        } catch (Exception ex) {
            ex.printStackTrace();
            return html;
        }
    }

    /**
     * 将html'中的相对路径替换为绝对路径，方便插入到word中
     * 默认使用配置文件中的路径
     *
     * @param html
     * @return
     */
    public static String processImgUrl(String html) {
        String fileurl = AddressUtils.getIp();
        return processImgUrl(html, fileurl);
    }

    public static void fitTableToPageWidth(Table table) {
        Section section = (Section) table.getAncestor(NodeType.SECTION);
        double tableWidth = 0;
        for (Row row : table.getRows()) {
            double rowWidth = 0;
            for (Cell cell : row.getCells()) {
                rowWidth += cell.getCellFormat().getWidth();
            }
            if (rowWidth > tableWidth) {
                tableWidth = rowWidth;
            }
        }
        double pageWidth = section.getPageSetup().getPageWidth() - (section.getPageSetup().getLeftMargin() + section.getPageSetup().getRightMargin());
        for (Row row : table.getRows()) {
            for (Cell cell : row.getCells()) {
                double cellRatio = cell.getCellFormat().getWidth() / tableWidth;
                cell.getCellFormat().setWidth(cellRatio * pageWidth);
            }
        }
    }

    /**
     * 替换上传文件路径
     * @return
     */
    public static String repairContent(String content,String fileurl){
        String patternStr="<img\\s*([^>]*)\\s*src=\\\"(.*?)\\\"\\s*([^>]*)>";
        Pattern pattern = Pattern.compile(patternStr,Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(content);
        String result = content;
        while(matcher.find()) {
            String src = matcher.group(2);
            String replaceSrc = fileurl+src;
            result = result.replaceAll(src,replaceSrc);
        }
        return result;
    }

}
