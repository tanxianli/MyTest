package com.jwind.comp.user;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author zhoujl
 * @date 2021/1/16
 */
public interface User extends Serializable {

    String getDeptCode();

    String getDeptId();

    String getDeptName();

    String getPrivLevel();

    String getOrgId();

    String getOrgName();

    String getPassword();

    List<String> getRoles();

    String getSubOrgId();

    String getSubOrgName();

    String getUserAttribute(String attribute);

    Map<String, String> getUserAttributes();

    String getUserDeptId();

    String getUserFullName();

    String getUserId();

    String getUserImageUrl();

    String getUsername();

    boolean isEnabled();

    String getUserAccount();

    boolean isTelenantAdminOrg();

    List<String> getAdminApp();

    String getDeptTreePath();

    String getOrgTreePath();

    String getSubOrgTreePath();

}
