package com.jwind.comp.anno;

import com.jwind.comp.anno.anenum.FieldDataType;
import com.jwind.comp.anno.anenum.FieldUpdateType;

import java.lang.annotation.*;

/**
 * @author zhoujl
 * @date 2021/1/13
 * dataType ==默认有 uuid  userid  sysdate
 */
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
public @interface FieldType {

    boolean primaryKey() default false;

    FieldUpdateType updateType();

    FieldDataType dataType();

}
