package com.jwind.comp.anno.anenum;

/**
 * @author zhoujl
 * @date 2021/1/13
 */
public enum FieldDataType {
    UUID,
    USERID,
    SYSDATE;
    private FieldDataType() {

    }
}
