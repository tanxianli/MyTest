package com.jwind.comp.dao;

import com.jwind.comp.anno.FieldType;
import com.jwind.comp.anno.anenum.FieldDataType;
import com.jwind.comp.anno.anenum.FieldUpdateType;
import com.jwind.comp.bean.BeanType;
import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.bean.util.BeanDaoHelper;
import com.jwind.comp.bean.BeanFiled;
import com.jwind.comp.bean.util.SpringBean;
import com.jwind.comp.manger.Mangerbean;
import com.jwind.comp.manger.bean.Ids;
import com.jwind.comp.manger.bean.Mapper;
import com.jwind.comp.manger.bean.Result;
import com.jwind.comp.user.User;
import com.jwind.comp.util.CompUtil;
import com.jwind.comp.util.UUIDUtil;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.cglib.beans.BeanMap;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;


public class BasicBeanDao<T extends IBomfBean> implements IBeanDao<T> {

    private Class<T> clz;
    private static final String insertStatement="BaseDao.insertbasebean";
    private static final String updateStatement="BaseDao.updatebsaebean";
    private static final String deleteStatement="BaseDao.deletebasebean";

    public BasicBeanDao() {
        Type superClass = getClass().getGenericSuperclass();
        if (superClass instanceof ParameterizedType) {
            Type type = ((ParameterizedType) superClass).getActualTypeArguments()[0];
            clz = (Class<T>) type;
        }
    }

    @Override
    public T queryById(String pk) throws Exception {
        BeanFiled beanFiled = this.getBeanDaoHelper().getBeanFiled(clz);
        Mapper mapper = Mangerbean.parBeanXml(beanFiled);
        Map params =  new HashMap();
        params.put(getPrimaryKey(mapper),pk);
        return this.getSqlTemplate().selectOne(mapper.getNamespace()+beanFiled.getQueryName(),params);
    }


    @Override
    public T saveInsert(T t, User user) throws Exception {
        Map beanMap =  BeanMap.create(t);
        BeanFiled beanFiled = this.getBeanDaoHelper().getBeanFiled(clz);
        Mapper mapper = Mangerbean.parBeanXml(beanFiled);
        this.createDefaultValue(beanMap,user,FieldUpdateType.INSERT);
        List<Map> requstList = new ArrayList<>();
        Map sqlm = new HashMap();
        List<Result> resultList = mapper.getResultMap().getResult();
        List<Ids> idsList = mapper.getResultMap().getIds();
        for(Ids bean:idsList) resultList.add(new Result(bean.getProperty(),bean.getColumn(),bean.getJdbcType()));
        for (Object key : beanMap.keySet()) {
            List<Result> listkey = resultList.stream().filter(e->key.equals(e.getProperty())).collect(Collectors.toList());
            if(listkey.size()==0) continue;
            Map hash = new HashMap();
            hash.put("key", listkey.get(0).getColumn());
            hash.put("value",beanMap.get(key));
            requstList.add(hash);
        }
        sqlm.put("table",beanFiled.getTablename());
        sqlm.put("requst",requstList);
        T bean = (T) CompUtil.mapToBean(beanMap,this.clz);
        this.preInsert(bean,beanMap,user);
        int code = this.getSqlTemplate().insert(insertStatement,sqlm);
        if(code>0) {
            this.afterInsert(bean,beanMap,user);
            return bean;
        }
        else throw new RuntimeException("添加失败");
    }

    @Override
    public int saveDelete(T t,User user) throws Exception {
        Map beanMap =  BeanMap.create(t);
        BeanFiled beanFiled = this.getBeanDaoHelper().getBeanFiled(clz);
        Mapper mapper = Mangerbean.parBeanXml(beanFiled);
        List<Map> requstList = new ArrayList<>();
        Map sqlm = new HashMap();
        String primaryKey =  this.getPrimaryKey(mapper);
        Map hash = new HashMap();
        hash.put("key",primaryKey);
        hash.put("value",beanMap.get(primaryKey));
        requstList.add(hash);
        sqlm.put("table",beanFiled.getTablename());
        sqlm.put("requst",requstList);
        T bean = (T) CompUtil.mapToBean(beanMap,this.clz);
        preDelete(bean,beanMap,user);
        int code = this.getSqlTemplate().delete(deleteStatement,sqlm);
        if(code>0) {
            afterDelete(bean,beanMap,user);
            return code;
        }
        else throw new RuntimeException("删除失败");
    }

    @Override
    public T saveUpdate(T t, User user) throws Exception {
        Map beanMap =  BeanMap.create(t);
        BeanFiled beanFiled = this.getBeanDaoHelper().getBeanFiled(clz);
        Mapper mapper = Mangerbean.parBeanXml(beanFiled);
        this.createDefaultValue(beanMap,user,FieldUpdateType.UPDATE);
        List<Map> requstList = new ArrayList<>();
        Map sqlm = new HashMap();
        List<Result> resultList = mapper.getResultMap().getResult();
        String primaryKey =  this.getPrimaryKey(mapper);
        sqlm.put("beanidkey",primaryKey);
        sqlm.put("beanidvalue",beanMap.get(primaryKey));
        for(Object key : beanMap.keySet()){
            List<Result> listkey = resultList.stream().filter(e->key.equals(e.getProperty())).collect(Collectors.toList());
            if(listkey.size()==0) continue;
            if(listkey.get(0).getProperty().equals(primaryKey)) continue;
            Map hash = new HashMap();
            hash.put("key", listkey.get(0).getColumn());
            hash.put("value",beanMap.get(key));
            requstList.add(hash);
        }
        sqlm.put("table",beanFiled.getTablename());
        sqlm.put("requst",requstList);
        T bean = (T) CompUtil.mapToBean(beanMap,this.clz);
        this.preUpdate(bean,beanMap,user);
        int code =  this.getSqlTemplate().update(updateStatement,sqlm);
        if(code>0) {
            this.afterUpdate(bean,beanMap,user);
            return bean;
        }
        else throw new RuntimeException("修改失败");
    }


    @Override
    public void preInsert(T bean,Map map,User user){

    }
    @Override
    public void afterInsert(T bean,Map map,User user){

    }

    @Override
    public void preUpdate(T bean,Map map,User user){

    }
    @Override
    public void afterUpdate(T bean,Map map,User user){

    }

    @Override
    public void preDelete(T bean,Map map,User user){

    }
    @Override
    public void afterDelete(T bean,Map map,User user){

    }

    private void createDefaultValue(Map map,User user,FieldUpdateType type){
        List<BeanType> var = filedBeanType(this.clz);
        List<BeanType> insertBeanTypes = var.stream().filter(e->e.getUpdateType().equals(type)).collect(Collectors.toList());
        for(BeanType beanType:insertBeanTypes){
           if(map.get(beanType.getFieldName())!=null) continue;
           Object obj = "";
           if(beanType.getDataType().equals(FieldDataType.UUID)) obj= UUIDUtil.getUUID();
           if(beanType.getDataType().equals(FieldDataType.SYSDATE)) obj= new Date();
           if(beanType.getDataType().equals(FieldDataType.USERID)) obj= user.getUserId();
           map.put(beanType.getFieldName(),obj);
        }
    }

    public BeanDaoHelper getBeanDaoHelper(){
        return SpringBean.getBean(BeanDaoHelper.class);
    }

    private SqlSessionTemplate getSqlTemplate(){return SpringBean.getBean(SqlSessionTemplate.class);}

    private <T extends IBomfBean>String getPrimaryKey(Mapper mapper) {
        String primaryKey=mapper.getResultMap().getIds().get(0).getProperty();
        List<BeanType> var = filedBeanType(this.clz);
        List<BeanType> PrimaryList = var.stream().filter(e->e.isPrimaryKey()).collect(Collectors.toList());
        if(PrimaryList.size()>0) primaryKey = PrimaryList.get(0).getFieldName();
        if(primaryKey==null) throw new RuntimeException(clz.toString()+"----->找不到对应主键");
        return primaryKey;
    }

    public List<BeanType> filedBeanType(Class cs){
        List<BeanType> retList = new ArrayList<>();
        Field[] fields = cs.getDeclaredFields();
        if (fields != null) {
            for (Field field : fields) {
                FieldType filetype = field.getAnnotation(FieldType.class);
                if(filetype==null) continue;
                BeanType beanType = new BeanType();
                beanType.setPrimaryKey(filetype.primaryKey());
                beanType.setDataType(filetype.dataType());
                beanType.setUpdateType(filetype.updateType());
                beanType.setFieldName(field.getName());
                retList.add(beanType);
            }
        }
        return retList;
    }

}
