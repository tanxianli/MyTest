package com.jwind.comp.manger.bean;

import javax.xml.bind.annotation.*;

/**
 * @author zhoujl
 * @date 2021/1/13
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(
        name = "mapper"
)
public class Mapper {

    @XmlAttribute(
            name = "namespace"
    )
    private String namespace;

    private ResultMap resultMap;

    public String getNamespace(){
        return this.namespace;
    }

    public void setNamespace(String namespace){
       this.namespace = namespace;
    }


    public ResultMap getResultMap() {
        return resultMap;
    }

    public void setResultMap(ResultMap resultMap) {
        this.resultMap = resultMap;
    }
}


