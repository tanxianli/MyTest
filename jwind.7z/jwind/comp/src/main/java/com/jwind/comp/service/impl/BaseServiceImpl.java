package com.jwind.comp.service.impl;

import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.service.BaseService;

import java.util.List;

/**
 * @author zhoujl
 * @date 2020/11/26
 */
public class BaseServiceImpl<T extends IBomfBean> implements BaseService<T> {


    @Override
    public List<T> getAllData() throws Exception {
        return null;
    }

    @Override
    public T queryById(String pk) throws Exception {
        return null;
    }

    @Override
    public T queryById(Class clazz, String pk) throws Exception {
        return null;
    }

    @Override
    public List<T> getAllData(Class clazz) throws Exception {
        return null;
    }
}
