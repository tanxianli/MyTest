package com.jwind.comp.manger.bean;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author zhoujl
 * @date 2021/1/14
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(
        name = "Result"
)
public class Result {
    @XmlAttribute(
            name = "property"
    )
    private String property;
    @XmlAttribute(
            name = "column"
    )
    private String column;
    @XmlAttribute(
            name = "jdbcType"
    )
    private String jdbcType;

    public Result(){

    }

    public Result(String property,String column,String jdbcType){
        this.property = property;
        this.column = column;
        this.jdbcType = jdbcType;
    }

    public String getProperty() {
        return property;
    }

    public void setProperty(String property) {
        this.property = property;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getJdbcType() {
        return jdbcType;
    }

    public void setJdbcType(String jdbcType) {
        this.jdbcType = jdbcType;
    }
}
