package com.jwind.comp.manger;

import com.jwind.comp.bean.BeanFiled;
import com.jwind.comp.manger.bean.Mapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author zhoujl
 * @date 2021/1/13
 */
public class Mangerbean {

    public static Mapper parBeanXml(BeanFiled beanFiled) throws Exception {
        Resource resource = new ClassPathResource(beanFiled.getXmlFile());
        InputStream inputStream =  resource.getInputStream();
        DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
        df.setNamespaceAware(true);
        Document document = df.newDocumentBuilder().parse(inputStream);
        JAXBContext context = JAXBContext.newInstance(Mapper.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        try {
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Assert.notNull(document, beanFiled.getXmlFile() + "对应的xml解释错误");
        Node queryRoot = document.getDocumentElement();
        Mapper bean = unmarshaller.unmarshal(queryRoot, Mapper.class).getValue();
        return bean;
    }

}
