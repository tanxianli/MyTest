package com.jwind.comp.bean;

import com.jwind.comp.anno.anenum.FieldDataType;
import com.jwind.comp.anno.anenum.FieldUpdateType;

/**
 * @author zhoujl
 * @date 2021/1/16
 */
public class BeanType {

    private boolean primaryKey;

    private FieldUpdateType updateType;

    private FieldDataType dataType;

    private String fieldName;


    public BeanType(){

    }

    public BeanType(boolean primaryKey,FieldUpdateType updateType,FieldDataType dataType,String fieldName){
        this.primaryKey = primaryKey;
        this.updateType = updateType;
        this.dataType = dataType;
        this.fieldName = fieldName;
    }


    public boolean isPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(boolean primaryKey) {
        this.primaryKey = primaryKey;
    }

    public FieldUpdateType getUpdateType() {
        return updateType;
    }

    public void setUpdateType(FieldUpdateType updateType) {
        this.updateType = updateType;
    }

    public FieldDataType getDataType() {
        return dataType;
    }

    public void setDataType(FieldDataType dataType) {
        this.dataType = dataType;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }
}
