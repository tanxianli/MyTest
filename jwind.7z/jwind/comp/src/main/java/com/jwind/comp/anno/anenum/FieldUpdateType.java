package com.jwind.comp.anno.anenum;

/**
 * @author zhoujl
 * @date 2021/1/13
 */
public enum FieldUpdateType {
    INSERT,
    UPDATE;
    private FieldUpdateType() {

    }

}
