package com.jwind.comp.bean.util;

import com.jwind.comp.bean.BeanFiled;
import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.dao.IBeanDao;
import com.jwind.comp.user.User;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/**
 * @author zhoujl
 * @date 2020/8/27
 */
public interface BeanDaoHelper {

    <T extends IBomfBean> T queryById(Class<T> cls, String pk) throws Exception;

    <T extends IBomfBean> BeanFiled getBeanFiled(Class<T> cls);

    <T extends IBomfBean> T saveInsert(Class<T> cls, T t, User user) throws Exception;

    <T extends IBomfBean>int saveDelete(Class<T> cls, T t, User user) throws Exception;

    <T extends IBomfBean> T saveUpdate(Class<T> cls, T t, User user) throws Exception;


}
