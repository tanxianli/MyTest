package com.jwind.comp.service;

import java.util.List;
import java.util.Map;

/**
 * @author zhoujl
 * @date 2020/11/26
 */
public interface BaseService<T> {

    List<T> getAllData() throws Exception;

    T queryById(String pk) throws Exception;

    T queryById(Class clazz,String pk) throws Exception;

    List<T> getAllData(Class clazz) throws Exception;

}
