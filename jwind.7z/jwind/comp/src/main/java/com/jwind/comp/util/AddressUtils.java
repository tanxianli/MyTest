package com.jwind.comp.util;

import com.alibaba.fastjson.JSONObject;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * @author zhoujl
 * @date 2020/11/26
 */
public class AddressUtils {

    //高德开发平台提供
    protected static String key = "759bd36a0d3a9036ea619e148c6f7910";
    protected static String requestUrl = "https://restapi.amap.com/v3/ip?output=json";


    public static String getAddresses(String ip) throws IOException {
        if(StringUtils.isEmpty(ip)) ip = getIp();
        String strurl = requestUrl+"&key="+key + "&ip=" + ip;
        URL url = new URL(strurl);
        HttpsURLConnection urlcon = (HttpsURLConnection) url.openConnection();
        urlcon.connect();
        BufferedReader br = new BufferedReader(new InputStreamReader(urlcon.getInputStream(),"utf-8"));
        StringBuffer sb = new StringBuffer();
        String content = null ;
        while((content=br.readLine())!=null) {
            sb.append(content);
        }
        JSONObject json = JSONObject.parseObject(sb.toString());
        String province = json.getString("province");
        String city = json.getString("city");
        String addr = province+"-"+city;
        if(city==""||city==null)addr = "内网ip无法解析*_*";
        return addr;
    }


    /**
     * @return 获取上下文中ip信息
     */
    public static String getIp(){
        RequestAttributes ra = RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes sra = (ServletRequestAttributes) ra;
        HttpServletRequest request = sra.getRequest();
        String requrl = request.getRequestURL().toString();
        String prefix = requrl.substring(0, 10);
        String other = requrl.substring(10);
        other = other.substring(0, other.indexOf('/'));
        return prefix + other;
    }
}
