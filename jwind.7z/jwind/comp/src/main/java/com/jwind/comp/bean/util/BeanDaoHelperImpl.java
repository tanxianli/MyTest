package com.jwind.comp.bean.util;

import com.jwind.comp.anno.MapperXml;
import com.jwind.comp.anno.Table;
import com.jwind.comp.bean.BeanFiled;
import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.dao.IBeanDao;
import com.jwind.comp.manger.bean.Mapper;
import com.jwind.comp.user.User;
import org.springframework.stereotype.Component;
import static com.jwind.comp.manger.Mangerbean.parBeanXml;

/**
 * @author zhoujl
 * @date 2021/1/12
 */
@Component
public class BeanDaoHelperImpl implements BeanDaoHelper {


    @Override
    public <T extends IBomfBean> T queryById(Class<T> cls, String pk) throws Exception {
        return (T) this.getBeanDao(getBeanFiled(cls)).queryById(pk);
    }

    @Override
    public <T extends IBomfBean> T saveInsert(Class<T> cls, T t, User user) throws Exception {
        return (T) this.getBeanDao(getBeanFiled(cls)).saveInsert(t,user);
    }

    @Override
    public <T extends IBomfBean> int saveDelete(Class<T> cls, T t, User user) throws Exception {
        return this.getBeanDao(getBeanFiled(cls)).saveDelete(t,user);
    }

    @Override
    public <T extends IBomfBean> T saveUpdate(Class<T> cls, T t, User user) throws Exception {
        return (T) this.getBeanDao(getBeanFiled(cls)).saveUpdate(t,user);
    }


    private <T extends IBomfBean> IBeanDao<T> getBeanDao(BeanFiled beanFiled) throws Exception {
        Mapper mapper = parBeanXml(beanFiled);
        return (IBeanDao) SpringBean.getBean(beanFiled.getCompId()+ mapper.getNamespace()+ "Dao");
    }

    @Override
    public  <T extends IBomfBean>BeanFiled getBeanFiled(Class<T> cls){
        String xmlFile = null;
        String compId = null;
        String tablename = null;
        String query = null;
        MapperXml mapperxml = cls.getAnnotation(MapperXml.class);
        if(mapperxml == null) throw new RuntimeException(cls.toString()+"----->缺少MapperXml注解");
        else{
            xmlFile =mapperxml.xmlFile();
            compId = mapperxml.compId();
            query = mapperxml.defaultQuery();
            if(xmlFile==null) throw new RuntimeException(cls.toString()+"----->MapperXml注解缺少xmlFile");
            if(compId==null) throw new RuntimeException(cls.toString()+"----->MapperXml注解缺少compId");
            if(query==null) throw new RuntimeException(cls.toString()+"----->MapperXml注解缺少defaultQuery");
        }
        if(cls.isAnnotationPresent(Table.class)){
            Table table = (Table) cls.getAnnotation(Table.class);
            tablename = table.name();
            if(tablename==null) throw new RuntimeException(cls.toString()+"----->Table注解缺少name");
        }else throw new RuntimeException(cls.toString()+"----->缺少Table注解");
        return new BeanFiled(compId,xmlFile,query,tablename);
    }

}
