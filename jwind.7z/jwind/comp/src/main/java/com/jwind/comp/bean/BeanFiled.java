package com.jwind.comp.bean;

/**
 * @author zhoujl
 * @date 2021/1/12
 */
public class BeanFiled {

    private String compId;

    private String xmlFile;

    private String queryName;

    private String tablename;

    public BeanFiled(String compId, String xmlFile,String queryName,String tablename){
        this.compId=compId;
        this.xmlFile = xmlFile;
        this.queryName = queryName;
        this.tablename = tablename;
    }

    public BeanFiled(){

    }

    public String getQueryName() {
        return ".".concat(queryName);
    }

    public void setQueryName(String queryName) {
        this.queryName = queryName;
    }

    public String getTablename() {
        return tablename;
    }

    public void setTablename(String tablename) {
        this.tablename = tablename;
    }

    public String getCompId() {
        return compId;
    }

    public void setCompId(String compId) {
        this.compId = compId;
    }

    public String getXmlFile() {
        return xmlFile;
    }

    public void setXmlFile(String xmlFile) {
        this.xmlFile = xmlFile;
    }
}
