package com.jwind.comp.dao;


import com.jwind.comp.bean.IBomfBean;
import com.jwind.comp.user.User;

import java.util.Map;


public interface IBeanDao<T> {

      T queryById(String pk) throws Exception;

      T saveInsert(T t, User user) throws Exception;

      int saveDelete(T t,User user) throws Exception;

      T saveUpdate(T t, User user) throws Exception;

      void preInsert(T t, Map map, User user);

      void afterInsert(T t,Map map,User user);

      void preUpdate(T bean,Map map,User user);

      void afterUpdate(T bean,Map map,User user);

      void preDelete(T bean,Map map,User user);

      void afterDelete(T bean,Map map,User user);
}
