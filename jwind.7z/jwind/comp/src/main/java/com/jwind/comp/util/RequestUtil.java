package com.jwind.comp.util;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * @author zhoujl
 * @date 2020/11/27
 */
public class RequestUtil {


}
