package com.jwind.comp.util;

import java.util.UUID;

/**
 * @author zhoujl
 * @date 2020/11/26
 */
public class UUIDUtil {

    public UUIDUtil() {
    }

    public static String getUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString().replace("-", "");
    }
}
